
package tube42.keyinfo;

import javax.microedition.lcdui.*;

/**
 * This class will handle the startup sequence states
 */

public class States
implements Runnable
{
    private Canvas canvas;
    private int state, count, time;
    private boolean paused;
    
    public States(Canvas canvas, int count, int time)
    {
        this.canvas = canvas;
        this.count = count;
        this.time = time;
        this.state = 0;
        this.paused = false;
        Thread t = new Thread(this);
        t.start();
    }
    
    // --------------------------------------
    // Runnable
    public void run()
    {
        for(int i = 0; i < count; i++) {
            state = i;
            
            do {
                try {
                    Thread.sleep( time);
                } catch(Exception ignored) { }
            } while(paused) ;
            canvas.repaint();            
        }
    }
    
    // --------------------------------------
    public void setPaused(boolean p)
    {
        this.paused = p;
    }
    
    public int getState()
    {
        return state;
    }
}

