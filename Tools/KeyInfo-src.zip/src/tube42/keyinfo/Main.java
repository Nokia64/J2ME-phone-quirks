
package tube42.keyinfo;


import javax.microedition.midlet.*;
import javax.microedition.lcdui.*;

public class Main extends MIDlet 
{        
    private KeyCanvas canvas;
    
    public Main() 
    {
        this.canvas = new KeyCanvas(this);   
    }    
    
    public void startApp() 
    {
        Display.getDisplay(this).setCurrent(canvas);
        canvas.setPaused(false);
    }
    
    public void pauseApp() 
    {
        canvas.setPaused(true);        
    }
    
    public void destroyApp(boolean unc) 
    {
        // EMPTY
    }              
}
