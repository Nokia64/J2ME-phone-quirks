
package tube42.keyinfo;

import javax.microedition.midlet.*;
import javax.microedition.lcdui.*;

/**
 * KeyInfo brain presentation and logic inthe same class
 */
public class KeyCanvas
extends Canvas
{
    // constants
    private static final String URL_HOME = "http://blog.tube42.se/?p=519";
    private static final int 
          // COLORS
          COLOR_BG = 0x000000,
          COLOR_FG = 0xFFFF80,
          COLOR_TUBE = 0x808080,
          COLOR_TOUCH_ACTIVE  = 0xFF0000,
          COLOR_TOUCH_PASSIVE = 0x800000,
          COLOR_KEY_STATE = 0x0000FF,
          COLOR_TOUCH_LINE = 0x204080,          
          // SCRREN DIMENSIONS
          GAP_Y = 5,
          GAP_X = 10,
          TOUCH_CIRCLE_SIZE = 5,
          TOUCH_HEIGHT = 22,
          // KEY AND TOUCH STATES
          KSTATE_NONE = 0,
          KSTATE_DOWN = 1,
          KSTATE_REPEAT = 2,
          KSTATE_UP = 3,
          // TIMING
          HELP_STATES_DELAY = 1500,
          // TIMER STATES
          TSTATE_HELP1 = 0,
          TSTATE_HELP2 = 1,
          TSTATE_HELP3 = 2,
          TSTATE_NORMAL = 3,
          TSTATE_COUNT = 4
          ;
    
    // ---------------------------------
    
    private MIDlet parent;
    private States states;
    private Font font1, font2;
    private int font1_h, font2_h;
    
    private String [] texts;
    
    private boolean seen_left, seen_right, seen_up, seen_down;
    private int touch1_x, touch1_y, touch2_x, touch2_y;
    private int touch_first, touch_curr;
    private int key_state, touch_state;        
    
    private int w, h, touch1_y1, touch2_y0;
    private int text_y0, text_y1;
    
    
    public KeyCanvas(MIDlet parent)
    {
        this.parent = parent;
        this.texts = new String[] { null, null, null };
                
        this.font1 = Font.getFont(Font.FACE_MONOSPACE, Font.STYLE_PLAIN, Font.SIZE_MEDIUM);
        this.font2 = Font.getFont(Font.FACE_SYSTEM, Font.STYLE_PLAIN, Font.SIZE_SMALL);       
        this.font1_h = font1.getHeight();
        this.font2_h = font2.getHeight();
        
        this.key_state = KSTATE_NONE;
        this.touch_state = KSTATE_NONE;        
        this.touch_curr = -1;        
        this.seen_left = false;
        this.seen_right = false;
        this.seen_up = false;
        this.seen_down = false;        
        
        // this function is not available in CLDC 1.0 ??
        setFullScreenMode(true);
        
        // start the timer
        this.states = new States(this, TSTATE_COUNT, HELP_STATES_DELAY);        
    }
    
    public void setPaused(boolean p)
    {
        states.setPaused(p);
    }
    
    // ---------------------------------------
    // key input
    public void keyPressed(int k)
    {
        handle_key( k, KSTATE_DOWN);
    }
    
    public void keyRepeated(int k)
    {
        handle_key( k, KSTATE_REPEAT);
    }
        
    public void keyReleased(int k)
    {
        handle_key(k, KSTATE_UP);        
    }
    
    
    
    public void pointerPressed(int x, int y)           
    {
        handle_touch(x, y, KSTATE_DOWN);
    }
    
    public void pointerDragged(int x, int y)     
    {
        handle_touch(x, y, KSTATE_REPEAT);        
    }
    
    public void pointerReleased(int x, int y)    
    {
        handle_touch(x, y, KSTATE_UP);                
    }
    
    // ---------------------------------------
    
    private void handle_key(int key, int state)
    {
        if(states.getState() != TSTATE_NORMAL) return; // dont handle input yet
        
        int gkey = getGameAction(key);
                
        if(state == KSTATE_DOWN) {
            if(gkey == LEFT) seen_left = true;
            if(gkey == RIGHT) seen_right = true; 
            if(gkey == UP) seen_up = true; 
            if(gkey == DOWN) seen_down = true; 
        } else if(state == KSTATE_UP) {            
            // exit when both are pressed
            if(seen_left && seen_right) { 
                seen_left = seen_right = false;
                do_action(0);
            }
            if(seen_up && seen_down) {
                seen_up = seen_down = false;
                do_action(1);                
            }
            
            if(gkey == LEFT) seen_left = false;
            if(gkey == RIGHT) seen_right = false; 
            if(gkey == UP) seen_up = false; 
            if(gkey == DOWN) seen_down = false;
        }
        
        key_state = state;        
        texts[0] = "Key code = " + key;
        texts[1] = "Game code = " + gkey;
        texts[2] = null;
        
        try {
            String x = getKeyName(key);
            if(x != null)
                texts[2] = "Key name = " + x;          
        } catch(Exception ignored) { }
        
        repaint();
    }
    
    private void handle_touch(int x, int y, int state)
    {
        // dont handle input in the beginning        
        if(states.getState() != TSTATE_NORMAL) return; 
        
        // was this a boutton?
        touch_curr = (y < touch1_y1) ? 0 : (y > touch2_y0) ? 1 : -1;
        if(state == KSTATE_DOWN) touch_first = touch_curr;
        else if(state == KSTATE_UP && (touch_curr == touch_first) && (touch_first != -1))
            do_action(touch_curr);
                
        // handle touch to screen
        touch2_x = x;
        touch2_y = y;
        touch_state = state;
        if(state == KSTATE_DOWN) {
            touch1_x = x;
            touch1_y = y;
        }
        repaint();
    }
    
    private void do_action(int type)
    {
        try {
            if(type == 0)
                parent.notifyDestroyed();
            else if(type == 1) 
                parent.platformRequest(URL_HOME);
        } catch(Exception ignored) { }
    }
        
    
    // ---------------------------------------
    public void paint(Graphics g)
    {
        init(getWidth(), getHeight() );                
                
        draw_background(g);
        draw_touch(g);
        
        // draw the real stuff
        int state = states.getState();        
        if(state == TSTATE_NORMAL)
            draw_normal(g);
        else 
            draw_help(g, state);
        
        // draw the text    
        draw_texts(g);        
        
    }
    
    private void init(int w_, int h_)
    {
        if(w == w_ && h == h_) return; // already initialized
        
        w = w_;
        h = h_;
        touch1_y1 = TOUCH_HEIGHT;
        touch2_y0 = h - TOUCH_HEIGHT;        
        text_y0 = touch1_y1 + Math.max(0, (touch2_y0 - touch1_y1 - 3 * font1_h) / 2);        
        text_y1 = text_y0 + 3 * font1_h;
    }
    
    private void draw_background(Graphics g)
    {
        // clear screen
        g.setColor(COLOR_BG);
        g.fillRect(0, 0, w, h);                
        
        // -----------------------------
        // draw exit and web bounadry
        g.setColor(COLOR_TOUCH_LINE);
        
        if(touch_curr == 0 || (seen_left && seen_right))
           g.fillRect(0, 0, w, touch1_y1);
        else
           g.drawRect(0, 0, w-1, touch1_y1-1);           
        
        if(touch_curr == 1 || (seen_up && seen_down))
           g.fillRect(0, touch2_y0, w, h - touch2_y0);
        else
           g.drawRect(0, touch2_y0, w-1, h - touch2_y0-1);
        
        // --------------------------
        // draw tube42 stuff        
        g.setFont(font2);        
        g.setColor(COLOR_TUBE);                
        g.drawString( "KeyInfo // tube42.se", w / 2, 
                  touch2_y0 + (h - touch2_y0 - font2_h) / 2, g.TOP | g.HCENTER);        
    }        
    
    private void draw_help(Graphics g, int state)
    {
        int x = 3 * w / 8;
        int size = TOUCH_HEIGHT / 3;
                                                                          
        switch(state)
        {        
        case TSTATE_HELP1:
            g.setColor( COLOR_TOUCH_ACTIVE);             
            g.fillArc(x - size, size, 2 * size, 2 * size, 0, 360);
            g.drawLine(x, size, x, text_y0);            
            texts = new String [] { "Tap here...", "or hold LEFT + RIGHT", "to exit." };
            break;
            
        case TSTATE_HELP2:            
            g.setColor( COLOR_TOUCH_ACTIVE); 
            g.fillArc(x - size, h-3*size, 2 * size, 2 * size, 0, 360);        
            g.drawLine(x, h-size, x, text_y1);            
            texts = new String [] { "To visit authors site,", "hold UP + DOWN", "...or tap here." };
            break;
            
        case TSTATE_HELP3:
            texts = new String [] { null, "Press any key...", null };
            break;            
        }
    }
    
    
    private void draw_normal(Graphics g)
    {
        int h_text = 3 * font1_h;
        // int y_text = y0 + h0 / 2 - h_text / 2;                                
        // draw key state               
        if(key_state == KSTATE_DOWN || key_state == KSTATE_REPEAT)  {                        
            int t = h_text * 2 / 3;            
            int a1 = w - GAP_Y;
            int a2 = a1 - 2 * t;
            int a3 = a1 - t;                  
            int b1 = text_y0;
            int b2 = text_y0 + t;
            
            g.setColor(COLOR_KEY_STATE);            
            g.fillTriangle(a1, b1, a2, b1, a3, b2);                  
            
            if(key_state == KSTATE_REPEAT) {
                b1 += t / 2;
                b2 += t / 2;
                g.fillTriangle(a1, b1, a2, b1, a3, b2);                  
            }
        }        
    }
    
    private void draw_touch(Graphics g)
    {
        g.setColor( touch_state == KSTATE_UP ? COLOR_TOUCH_PASSIVE : COLOR_TOUCH_ACTIVE);                 
        if(touch_state != KSTATE_NONE) {
            g.fillArc(touch1_x - TOUCH_CIRCLE_SIZE, touch1_y - TOUCH_CIRCLE_SIZE,
                      2 * TOUCH_CIRCLE_SIZE, 2 * TOUCH_CIRCLE_SIZE, 0, 360);
        }
        if(touch_state != KSTATE_NONE && touch_state != KSTATE_DOWN) {
            g.fillArc(touch2_x - TOUCH_CIRCLE_SIZE, touch2_y - TOUCH_CIRCLE_SIZE,
                      2 * TOUCH_CIRCLE_SIZE, 2 * TOUCH_CIRCLE_SIZE, 0, 360);
            g.drawLine(touch1_x, touch1_y, touch2_x, touch2_y);            
        }
    }
        
    private void draw_texts(Graphics g)
    {
        g.setFont(font1);        
        g.setColor(COLOR_FG);        
        
        int y = text_y0;        
        for(int i = 0; i < texts.length; i++) {
            if(texts[i] != null)
                g.drawString( texts[i], GAP_X, y, 0);             
            y += font1_h;
        }
    }
    
}
