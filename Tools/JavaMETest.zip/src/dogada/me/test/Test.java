/*
 * JavaME Test Suite
 * Copyright (C) 2002 Dmytro Dogadaylo
 * 
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 * 
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * Test.java
 *
 */

package dogada.me.test;

import javax.microedition.lcdui.*;

/**
 * This inerface should implement all tests.
 * @author  Dmytro Dogadaylo, self@dogada.com
 * @version 
 */

public interface Test {

    /**
     * Midlet passes to test display and displayable that should 
     * be shown when current test finish its work.
     */
    void init(Display display, Displayable next);
    
    /**
     * Returns displayable object for the test.
     */
    Displayable getDisplayable();
    
    /**
     * Shows test.
     */
    public void showTest();
    
    /**
     * Test should stop all it threads if any.
     */
    public void killTest();
    
    /**
     * Return help string for the test or null if help 
     * isn't provided.
     */
    public String getHelp();
    
    
}