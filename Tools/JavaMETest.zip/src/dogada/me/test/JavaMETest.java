/*
 * JavaME Test Suite
 * Copyright (C) 2002 Dmytro Dogadaylo
 * 
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 * 
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 *
 * JavaMETest.java
 *
 * Created on 17 Apr 2002, 18:15
 */

package dogada.me.test;

import javax.microedition.midlet.*;
import javax.microedition.lcdui.*;

/** 
 * Main MIDlet with test list.
 *
 * @author  Dmytro Dogadaylo, self@dogada.com
 * @version 1.0
 */
public class JavaMETest extends MIDlet implements CommandListener {

    private Command exitCmd, doCmd, helpCmd;
    private List list;
    
    private String[] testNames = 
    {"Properties",
     "FillRectTest",
     "DrawImageTest",
     "CalcTest",
     "Colors",
     "Sounds",
     "Fonts"
    };

    private String[] testClases = 
    {"dogada.me.test.DeviceProperties",
     "dogada.me.test.FillRectTest",
     "dogada.me.test.DrawImageTest",
     "dogada.me.test.CalcTest",
     "dogada.me.test.ColorTest",
     "dogada.me.test.SoundTest",
     "dogada.me.test.FontTest"
    };
    
    private static Display display;
    private Test test;
    
    public JavaMETest() {
        display = Display.getDisplay(this);
        
        exitCmd = new Command("Exit", Command.SCREEN, 2);
        helpCmd = new Command("Help", Command.HELP, 2);
        
        list = new List("JavaME Test", List.IMPLICIT, testNames, null);
        
        list.addCommand(exitCmd);
        list.addCommand(helpCmd);
        
        list.setCommandListener(this);
    }

    
    /**
     * Start up the Hello MIDlet by creating the TextBox and associating
     * the exit command and listener.
     */
    public void startApp() {
        display.setCurrent(list);
    }

    /**
     * Pause is a no-op since there are no background activities or
     * record stores that need to be closed.
     */
    public void pauseApp() {
        killTest();
        display.setCurrent(list);
    }

    /**
     * Destroy must cleanup everything not handled by the garbage collector.
     * In this case there is nothing to cleanup.
     */
    public void destroyApp(boolean unconditional) {
        killTest();
    }

    private void killTest() {
        if (test != null)
            test.killTest();
        test = null;
    }
    
    /*
     * Respond to commands, including exit
     * On the exit command, cleanup and notify that the MIDlet has been destroyed.
     */
    public void commandAction(Command c, Displayable s) {
        if (c == List.SELECT_COMMAND) {
            int pos = list.getSelectedIndex();
            String clazz = null;
            try {
                clazz = testClases[pos];
                test = (Test) Class.forName(clazz).newInstance();
                test.init(display, list);
                test.showTest();
            } catch (Exception e) {
                System.err.println(e);
                Alert alert = new Alert("Test failed", e.toString(), null, AlertType.ERROR);
                alert.setTimeout(Alert.FOREVER);
                display.setCurrent(alert);
                return;
            }
        } else if (c == helpCmd) {
            showInfo(helpStr);
        } else if (c == exitCmd) {
            destroyApp(false);
            notifyDestroyed();
        }
    }
    
    public static void showInfo(String info) {
        Alert help = new Alert("Help", info, null, AlertType.INFO);
        help.setTimeout(Alert.FOREVER);
        display.setCurrent(help);
    }
    
    private static final String helpStr = 
    "Midlet is intended for testing devices with J2ME support.\n" +
    "For instructions and test results see www.dogada.com/javame/\n" + 
    "If you send the test results for your device to javame@dogada.com, " + 
    "I add it to the common freely available list.\n" +
    "Dmytro Dogadaylo,\n" + 
    "self@dogada.com";
}