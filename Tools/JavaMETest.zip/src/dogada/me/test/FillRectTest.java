/*
 * JavaME Test Suite
 * Copyright (C) 2002 Dmytro Dogadaylo
 * 
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 * 
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 *
 * FillRectTest.java
 *
 */

package dogada.me.test;

import javax.microedition.lcdui.*;

/**
 *
 * @author  Dmytro Dogadaylo, self@dogada.com
 * @version 1.0
 */
public class FillRectTest extends FPSTest {

    int rectSize = 10;
    
    /**
     * paint
     */
    protected void paint(Graphics g) {
        long paintTime = System.currentTimeMillis();
        int x = g.getClipX();
        int y = g.getClipY();
        int w = g.getClipWidth();
        int h = g.getClipHeight();
        int x2 = x + w;
        int y2 = y + h;
        
        int drawCount = 0, color = 0;
        int prevColor = 0;
        for (int i = y; i < y2; i += rectSize) {
            color = ~prevColor & 0xFFFFFF;
            prevColor = color;
            for (int j = x; j < x2; j += rectSize) {
                g.setColor(color);
                g.fillRect(j, i, rectSize, rectSize);
                drawCount++;
                color = color == 0 ? 0xFFFFFF : 0;
            }
            
        }
        paintTime = System.currentTimeMillis() - paintTime;
        
        String mes = rectSize + "x" + rectSize + "x" + drawCount + 
        "=" + paintTime + "ms";
        
        drawInfo(mes, g, x, y, x2, y2);
        
        super.paint(g);
    }

    public String getHelp() {
        String helpStr = 
        "UP/DOWN - changes rect size\n" + 
        "FIRE - show/hide fps indicator"; 
        return helpStr;
    }    
    
    protected void handleKey(int keyCode) {
        int action = getGameAction(keyCode);
        boolean changed = false;
        switch (action) {
            case UP:
                if (rectSize < getWidth()) {
                    rectSize++;
                    changed = true;
                }
                break;
                
            case DOWN:
                if (rectSize > 1) {
                    rectSize--;
                    changed = true;
                }
                break;
            default:
                super.handleKey(keyCode);
        }
        if (changed)
            reset();
    }
}