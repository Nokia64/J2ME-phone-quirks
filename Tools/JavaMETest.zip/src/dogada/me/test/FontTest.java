/*
 * JavaME Test Suite
 * Copyright (C) 2002 Dmytro Dogadaylo
 * 
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 * 
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * FontTest.java
 *
 */

package dogada.me.test;


import javax.microedition.lcdui.*;

/**
 *
 * @author  Dmytro Dogadaylo, self@dogada.com
 * @version 
 */
public class FontTest extends TestCanvas {

    private int[] faces = 
    {Font.FACE_PROPORTIONAL, Font.FACE_MONOSPACE, Font.FACE_SYSTEM};
    
    private String[] faceNames = 
    {"proportional", "monospace", "system"};
    
    private int[] styles = 
    {Font.STYLE_PLAIN, Font.STYLE_BOLD, Font.STYLE_ITALIC, 
     Font.STYLE_BOLD & Font.STYLE_ITALIC, Font.STYLE_UNDERLINED};
     
     private String[] styleNames = 
    {"plain", "bold", "italic", "bold&italic", "underlined"};
     
     
    private int faceIndex, styleIndex; 

    private int[] sizes = 
    {Font.SIZE_SMALL, Font.SIZE_MEDIUM, Font.SIZE_LARGE};
    
    private Font f;
    private int fHeight;
    private int infoColor = 0xFF0000;
    
    private String testStr = "Phones are strange...";
    
    /** Creates new FontTest */
    public FontTest() {
    }

    public void init(Display display, Displayable next) {
        super.init(display, next);
        f = Font.getFont(Font.FACE_SYSTEM, Font.STYLE_PLAIN, Font.SIZE_SMALL);
        fHeight = f.getHeight();
    }
    
    protected void paint(Graphics g) {
        g.setColor(0xFFFFFF);
        g.fillRect(0,0, width, height);
        
        Font font = null;
        int x = 1, y = 1, strWidth, strHeight;
        
        g.setColor(infoColor);
        g.setFont(f);
        String info = faceNames[faceIndex] + "/" + styleNames[styleIndex];
        g.drawString(info, x, y, Graphics.TOP | Graphics.LEFT);
        y += fHeight + 1;
        
        for (int i=0; i<sizes.length; i++) {
            font = Font.getFont(faces[faceIndex], styles[styleIndex], sizes[i]);
            if (font != null) {
                g.setColor(0);
                g.setFont(font);
                g.drawString(testStr, x, y, Graphics.TOP | Graphics.LEFT);
                strWidth = font.stringWidth(testStr);
                strHeight = font.getHeight();
                y += strHeight;
                
                g.setColor(infoColor);
                g.setFont(f);
                info = "h: " + strHeight + "  w:" + strWidth;
                g.drawString(info, x, y, Graphics.TOP | Graphics.LEFT);
                y += fHeight;
            }
        }
    }

    protected void handleKey(int keyCode) {
        int action = getGameAction(keyCode);
        switch (action) {
            case UP:
                faceIndex++;
                if (faceIndex >= faces.length)
                    faceIndex = 0;
                break;
                
            case DOWN:
                faceIndex--;
                if (faceIndex < 0)
                    faceIndex = faces.length - 1;
                break;
                
            case LEFT:
                styleIndex--;
                if (styleIndex < 0)
                    styleIndex = styles.length -1;
                break;
                
            case RIGHT:
                styleIndex++;
                if (styleIndex >= styles.length)
                    styleIndex = 0;
                break;
                
            case FIRE:
        }
        repaint();
    }
    
    public String getHelp() {
        String helpStr = 
        "UP/DOWN - changes font face\n" + 
        "LEFT/RIGHT - changes font style"; 
        return helpStr;
    }
}