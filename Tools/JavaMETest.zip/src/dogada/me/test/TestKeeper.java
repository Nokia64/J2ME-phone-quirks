/*
 * JavaME Test Suite
 * Copyright (C) 2002 Dmytro Dogadaylo
 * 
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 * 
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 *
 * TestKeeper.java
 *
 */

package dogada.me.test;

import javax.microedition.lcdui.*;

/**
 * Used for simple tests that isn't need Canvas.
 * @author  Dmytro Dogadaylo, self@dogada.com
 * @version 
 */
public abstract class TestKeeper implements Test, CommandListener {

    protected Display display; 
    protected Displayable next;
    protected Command backCmd, helpCmd;

    
    public void init(Display display, Displayable next) {
        this.display = display;
        this.next = next;
        backCmd = new Command("Back", Command.BACK, 3);
        getDisplayable().addCommand(backCmd);
        helpCmd = new Command("Help", Command.HELP, 5);
        
        if (getHelp() != null)
            getDisplayable().addCommand(helpCmd);
        
        getDisplayable().setCommandListener(this);
    }    

    public void commandAction(Command c, Displayable s) {
        if (c == backCmd) {
            killTest();
            display.setCurrent(next);
        }
        else if (c == helpCmd) {
            JavaMETest.showInfo(getHelp());
        }
    }

    public void showTest() {
        display.setCurrent(getDisplayable());
    }
    
    public void killTest() {
    }
    
    public String getHelp() {
        return null;
    }
}