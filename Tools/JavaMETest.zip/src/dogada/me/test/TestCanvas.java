/*
 * JavaME Test Suite
 * Copyright (C) 2002 Dmytro Dogadaylo
 * 
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 * 
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 *
 * TestCanvas.java
 *
 */

package dogada.me.test;

import javax.microedition.lcdui.*;

/**
 *
 * @author  Dmytro Dogadaylo, self@dogada.com
 * @version 
 */
public abstract class TestCanvas extends Canvas implements Test, CommandListener {
   
    protected Display display; 
    protected Displayable next;
    protected Command backCmd, helpCmd;
    
    protected int width, height;

    public void init(Display display, Displayable next) {
        this.display = display;
        this.next = next;
        width = getWidth();
        height = getHeight();
        backCmd = new Command("Back", Command.BACK, 10);
        helpCmd = new Command("Help", Command.HELP, 15);
        
        addCommand(backCmd);
        if (getHelp() != null)
            addCommand(helpCmd);
        setCommandListener(this);
    }
    
    public Displayable getDisplayable() {
        return this;
    }
    
    public void showTest() {
        display.setCurrent(getDisplayable());
    }    

    public void killTest() {
    }
    
    public void commandAction(Command c, Displayable s) {
        if (c == backCmd) {
            killTest();
            display.setCurrent(next);
        }
        else if (c == helpCmd) {
            JavaMETest.showInfo(getHelp());
        }
    }
    
    protected void handleKey(int keyCode) {
    }
    
    /**
     * Called when a key is pressed.
     */
    protected  void keyPressed(int keyCode) {
        handleKey(keyCode);
    }

    /**
     * Called when a key is repeated (held down).
     */
    protected  void keyRepeated(int keyCode) {
        handleKey(keyCode);
    }
}