/*
 * JavaME Test Suite
 * Copyright (C) 2002 Dmytro Dogadaylo
 * 
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 * 
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 *
 * Colors.java
 *
 */

package dogada.me.test;

import javax.microedition.lcdui.*;

/**
 *
 * @author  Dmytro Dogadaylo, self@dogada.com
 * @version 
 */
public class ColorTest extends TestCanvas {

    private Image view;
    private int viewX, viewY, viewWidth, viewHeight;
    private int minColorHeight = 8;
    
    private int[] steps = {1, 2, 4, 8, 16, 32, 48, 64, 128};
    private int stepIndex = 2;
    
    private boolean delimColor;
    
    private Font font;    

    public void init(Display display, Displayable previous) {
        super.init(display, previous);
        font = Font.getFont(Font.FACE_PROPORTIONAL, Font.STYLE_PLAIN, Font.SIZE_SMALL);
        updateView();
    }
    
    /**
     * paint
     */
    protected void paint(Graphics g) {
        g.setColor(0xFFFFFF);
        g.fillRect(0,0, width, height);
        
        g.drawImage(view, viewX, viewY, Graphics.TOP | Graphics.LEFT);
        
        int shades = 256/steps[stepIndex];
        String info = shades + " shades";
        int infoWidth = font.stringWidth(info);
        int infoHeight = font.getHeight();
        
        g.setColor(0xFFFFFF);
        g.fillRect((width - infoWidth - 1)/2, height - infoHeight-2, infoWidth + 2, infoHeight + 2);
        g.setColor(0);
        g.setFont(font);
        g.drawString(info, width/2, height - infoHeight-1, Graphics.TOP | Graphics.HCENTER);
    }

    
    private void updateView() {
        int step = steps[stepIndex];
        int colorCount = 256/step;
        int colorWidth = width/colorCount + 1;

        int markHeight = font.getHeight();
        int unitHeight = 2, freeSpaceHeight = 4, freeSpaceWidth = 2;
        int infoHeight = markHeight + unitHeight + 1 + 2 + freeSpaceHeight;
        int colorHeight = (height - 4*infoHeight)/4;
        if(colorHeight < minColorHeight)
            colorHeight = minColorHeight;
        
        viewWidth = colorWidth*colorCount + 2 + 2*freeSpaceWidth;
        if (delimColor)
            viewWidth += colorCount - 1;
        viewHeight = 4*(colorHeight + infoHeight) + 2*font.getHeight();
        view = Image.createImage(viewWidth, viewHeight);

        System.out.println("step=" + step + " colorCount=" + colorCount + " colorWidth=" + colorWidth);
        
        Graphics g = view.getGraphics();
        g.setColor(0xFFFFFF);
        g.fillRect(0, 0, viewWidth, viewHeight);
        
        int[] offsets = {16, 8, 0, -1};
        int x=0, y=0;
        
        for (int i = 0; i < 4; i++) {
            x = freeSpaceWidth;
            y += freeSpaceHeight;
            int lastMarkEndX = -1995; //It should be enough
            
            //painting border
            g.setColor(0);
            int borderWidth = colorCount*colorWidth + 1;
            if (delimColor)
                borderWidth += colorCount -1;
            
            g.drawRect(x++, y++, borderWidth, colorHeight + 1);
            
            //painting color, units, and marks
            for (int j=0; j < colorCount; j++) {
                int colorIndex = j*step;
                if (colorIndex > 0xFF)
                    colorIndex = 0xFF;
                int color = colorIndex;
                if (offsets[i] >= 0) {
                    color <<= offsets[i];
                    g.setColor(color);
                }
                else {
                    g.setGrayScale(color);
                }

                g.fillRect(x, y, colorWidth, colorHeight);
                
                if (delimColor && j > colorCount -1 ) {
                    g.setColor(0xFFFFFF);
                    g.drawLine(x + colorWidth, y, x + colorWidth, y + colorHeight-1);
                }
                
                if ((colorIndex & 0x0F) == 0) {
                    //painting unit
                    g.setColor(0);
                    int unitY = y + colorHeight +1;
                    g.drawLine(x, unitY, x, unitY + unitHeight);
                    
                    //painting mark
                    String mark = Integer.toHexString(colorIndex);
                    int markWidth = font.stringWidth(mark);
                    if (lastMarkEndX +2 < x - markWidth/2) {
                        g.setFont(font);
                        g.drawString(mark, x - markWidth/2, unitY + unitHeight + 1, Graphics.TOP | Graphics.LEFT);
                        lastMarkEndX = x + markWidth/2;
                    }
                }

                x += colorWidth;
                if (delimColor)
                    x++;
            }
            
            y+= colorHeight + 2 + unitHeight + 1 + markHeight;
        }
        System.out.println("Update is finished " + step + " colorCount=" + colorCount);
    }

    public String getHelp() {
        String helpStr = 
        "UP/DOWN - scrolls screen by vertical\n" + 
        "LEFT/RIGHT - scrolls screen by horizontal\n" + 
        "FIRE - changes color step\n" + 
        "GAME_A - show/hide delims between colors."; 
        return helpStr;
    }    
    
    protected void handleKey(int keyCode) {
        int action = getGameAction(keyCode);
        switch (action) {
            case UP:
                viewY += height/2;
                if (viewY > 0)
                    viewY = 0;
                break;
                
            case DOWN:
                viewY -= height/2;
                if (viewY < height - viewHeight)
                    viewY = height - viewHeight;
                break;
                
            case LEFT:
                viewX += width/2;
                if (viewX > 0)
                    viewX = 0;
                break;
                
            case RIGHT:
                viewX -= width/2;
                if (viewX < width - viewWidth)
                    viewX = width - viewWidth;
                break;
                
            case FIRE:
                stepIndex++;
                if (stepIndex >= steps.length)
                    stepIndex = 0;
                updateView();
                viewX = viewY = 0;
                break;
            case GAME_A:
                delimColor = !delimColor;
                updateView();
                viewX = viewY = 0;
                break;
        }
        repaint();
    }
}