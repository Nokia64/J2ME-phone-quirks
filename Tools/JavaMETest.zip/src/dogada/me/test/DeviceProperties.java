/*
 * JavaME Test Suite
 * Copyright (C) 2002 Dmytro Dogadaylo
 * 
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 * 
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * DeviceProperties.java
 *
 */

package dogada.me.test;

import javax.microedition.lcdui.*;

/**
 * Device properties (colors, memory, canvas dimension, system properties).
 * @author Dmytro Dogadaylo, self@dogada.com
 * @version 1.0
 */
public class DeviceProperties extends TestKeeper {

    private static String[] props = {
        "microedition.configuration",
        "microedition.profiles",
        "microedition.platform",
        "microedition.locale",
        "microedition.encoding",
    };
    
    private Canvas canvas = new Canvas () {
        public void paint(Graphics g) {}
    };    
    
    private Form form;
    

    public void init(Display display, Displayable next) {
        form = new Form("Properties");
        super.init(display, next);
        
        Runtime runtime = Runtime.getRuntime();
        runtime.gc();
        long freeMem = runtime.freeMemory();
        long totalMem = runtime.totalMemory();
        append("totalMemory", totalMem);
        append("freeMemory", freeMem);
        
        append("isColor", display.isColor());
        append("numColors", display.numColors());
        
        append("Canvas width", canvas.getWidth());
        append("Canvas height", canvas.getHeight());
        append("isDoubleBuffered", canvas.isDoubleBuffered());
        
        append("hasRepeatEvents", canvas.hasRepeatEvents());
        
        append("hasPointerEvents", canvas.hasPointerEvents());
        append("hasPointerMotionEvents", canvas.hasPointerMotionEvents());

        for (int i=0; i<props.length; i++) {
            append(props[i], System.getProperty(props[i]));
        }
    }

    private void append(String label, boolean value) {
        append(label, String.valueOf(value));
    }
    
    private void append(String label, long value) {
        append(label, String.valueOf(value));
    }
    
    private void append(String label, int value) {
        append(label, String.valueOf(value));
    }
    
    private void append(String label, String text) {
        form.append(new StringItem(label, (text!=null ? " " + text + "\n" : null) ));
    }
    
    public Displayable getDisplayable() {
        return form;
    }
}