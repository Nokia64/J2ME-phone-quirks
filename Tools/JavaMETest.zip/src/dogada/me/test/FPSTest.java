/*
 * JavaME Test Suite
 * Copyright (C) 2002 Dmytro Dogadaylo
 * 
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 * 
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 *
 * FPSTest.java
 *
 */

package dogada.me.test;

import javax.microedition.lcdui.*;

/**
 *
 * @author  Dmytro Dogadaylo, self@dogada.com
 * @version 1.0
 */
public abstract class FPSTest extends TestCanvas implements Runnable {
    public static final int
    ZERO_INFO = 0,
    FPS_INFO = 1,
    PAINT_INFO = 2,
    MIN_INFO = ZERO_INFO,
    MAX_INFO = PAINT_INFO;
    
    protected Command toggleCmd;
    
    //current value of frames per second
    protected long fps = 0;
    
    //float-point view of fps 
    protected String fpsStr;
    
    //default delay between repaint() calls.  
    protected long defaultDelay = 50;
    
    //time of the last reset()
    protected long startTime;
    
    
    //frames painted after last reset()
    protected int frameCount;
    
    //x-coordinate of the rendering speed indicator
    protected int speedX = 0;

    protected boolean showFPS = true;

    protected int infoLevel = PAINT_INFO;
    
    protected Font font;
    
    protected int infoHeight;
    
    private Thread renderThread;
    
    public void init(Display display, Displayable next) {
        super.init(display, next);
        //toggleCmd = new Command("Stop/Go", Command.SCREEN, 1);
        //addCommand(toggleCmd);
        font = Font.getFont(Font.FACE_SYSTEM, Font.STYLE_PLAIN, Font.SIZE_MEDIUM);
        infoHeight = font.getHeight() + 2;
    }

    /*
    public void commandAction(Command c, Displayable s) {
        if (c == toggleCmd) {
            if (isPaused())
                start();
            else
                pause();
            display.setCurrent(this);
        }
        else {
            super.commandAction(c, s);
        }
    }
    */
    
    public void showNotify() {
        start();
    }

    public void hideNotify() {
        pause();
    }

    public void killTest() {
        pause();
    }
    
    /**
     * Handles pressed and repeated keys.
     */
    protected void handleKey(int keyCode) {
        if (getGameAction(keyCode) == FIRE) {
            infoLevel++;
            if (infoLevel > MAX_INFO)
                infoLevel = MIN_INFO;
            reset();
        }
    }

    /**
     * Paints fps indicator and notifies repaint thread.
     */
    protected void paint(Graphics g) {
        frameCount++;
        
        if (infoLevel >= FPS_INFO) {
            updateFPS();
            
            int w = font.stringWidth(fpsStr) + 2;
            int h = font.getHeight() + 2;
            
            int x = width/2 - w/2;
            int y = height/2 - h/2;
            
            g.setColor(0xFFFFFF);
            g.fillRect(x, y, w, h);
            g.setColor(0);
            g.setFont(font);
            g.drawString(fpsStr, x+1, y, Graphics.TOP | Graphics.LEFT);
        }
    }
    
    public void run() {
        Thread currentThread = Thread.currentThread();
        while (currentThread == renderThread) {
            repaint();
            serviceRepaints();
        }
    }

    /**
     * Calculates fps based on test time and painted frame count.
     */
    protected void updateFPS() {
        long p = 0;
        
        long time = System.currentTimeMillis() - startTime;
        if (time > 0) {
            long fpsX100 = (frameCount*1000*100)/time;
            fps = fpsX100/100;
            p = fpsX100 % 100;
        }
        fpsStr = fps + "." + (p<10?"0":"") + p + "fps";
    }
    
    protected void drawInfo(String mes, Graphics g, int x, int y, int x2, int y2) {
        if (infoLevel >= PAINT_INFO) {
            
            //draw border (top and bottom lines)
            g.setColor(0);
            g.drawRect(x-1, y, x2 - x+1, infoHeight);
            
            //fill
            g.setColor(0xffffff);
            g.fillRect(x, y + 1, x2 - x, infoHeight-1);
            
            //draw message
            g.setColor(0);
            g.setFont(font);
            g.drawString(mes, x+1, y + 1, Graphics.TOP | Graphics.LEFT);
            
            //draw speed indicator
            if (++speedX >= x2)
                speedX = x;
            g.setColor(0xff0000);
            g.fillRect(speedX, y+infoHeight, 5, 7);
            
        }
    }

    
    public synchronized void start() {
        reset();
        renderThread = new Thread(this);
        renderThread.start();
    }
    
    public synchronized void pause() {
        renderThread = null;
    }
    
    public  synchronized boolean isPaused() {
        return (renderThread == null);
    }
    
    public void destroy() {
        pause();
    }

    void reset() {
        startTime = System.currentTimeMillis();
        frameCount = 0;
    }
}