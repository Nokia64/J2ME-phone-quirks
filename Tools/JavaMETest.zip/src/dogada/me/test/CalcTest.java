/*
 * JavaME Test Suite
 * Copyright (C) 2002 Dmytro Dogadaylo
 * 
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 * 
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * CalcTest.java
 *
 */

package dogada.me.test;


import javax.microedition.lcdui.*;

/**
 * Measures time of executing below statement:
 * <pre>
        int temp = 0;
        for (int i = 0; i < 100000; i++) {
            temp = (temp*i)/(i+1) + i;
        }
   </pre> 
 * @author  Dmytro Dogadaylo, self@dogada.com
 * @version 
 */
public class CalcTest extends TestKeeper implements Runnable {

    private static final int PASS_COUNT = 3;
    private Form form;
    private Thread calcThread;
    
    int pass;
    long totalTime;
    private String testName;
    
    public void init(Display display, Displayable next) {
        testName = getClass().getName();
        if (testName.lastIndexOf('.') > 0)
            testName = testName.substring(testName.lastIndexOf('.')+1, testName.length());
        form = new Form(testName);
        super.init(display, next);
    }

    public void showTest() {
        super.showTest();
        start();
    }
    
    public void killTest() {
        calcThread = null;
    }
    
    
    /**
     * Returns displayable object for the test.
     */
    public Displayable getDisplayable() {
        return form;
    }
    
    public void reset() {
        totalTime = 0;
        pass = 0;
        int size = form.size();
        while (size > 0)
            form.delete(--size);
    }
    
    public synchronized void start() {
        reset();
        calcThread = new Thread(this);
        calcThread.start();
    }
    
    protected void doCalc() {
        int temp = 0;
        for (int i = 0; i < 100000; i++) {
            temp = (temp*i)/(i+1) + i;
        }
    }
    
    private void append(String label, String text) {
        form.append(new StringItem(label, (text!=null ? " " + text + "\n" : null) ));
    }
    
    public void run() {
        Thread currentThread = Thread.currentThread();
        append(testName, "is started. One passage can take time up to 30 seconds.");
        while (currentThread == calcThread && pass < PASS_COUNT) {
            long time = System.currentTimeMillis();
            doCalc();
            pass++;
            time = System.currentTimeMillis() - time;
            totalTime += time;
            if (currentThread == calcThread)
                append("Passage " + pass + "(" + PASS_COUNT + ")", time + "ms.");
        }
        if (currentThread == calcThread) {
            append(testName, "is finished.");
            append("Avg time", totalTime/pass + "ms.");
            append("Total passages:", pass + ".");
        }
    }
}