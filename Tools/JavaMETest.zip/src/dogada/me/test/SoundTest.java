/*
 * JavaME Test Suite
 * Copyright (C) 2002 Dmytro Dogadaylo
 * 
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 * 
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 *
 * SoundTest.java
 *
 */

package dogada.me.test;

import javax.microedition.lcdui.*;

/**
 *
 * @author  Dmytro Dogadaylo, self@dogada.com
 * @version 
 */
public class SoundTest extends TestKeeper {

    private List list;
    private Command playCmd;
    
    private String[] ids = 
    {"ALARM", "CONFIRMATION", "ERROR", "INFO", "WARNING"};
    
    private AlertType[] alerts = 
    {AlertType.ALARM, AlertType.CONFIRMATION, AlertType.ERROR, 
     AlertType.INFO, AlertType.WARNING};
        
    public void init(Display display, Displayable next) {
        list = new List("Sound", List.IMPLICIT, ids, null);
        super.init(display, next);
        
        playCmd = new Command("Play", Command.BACK, 10);
        list.addCommand(playCmd);
    }

    
    public Displayable getDisplayable() {
        return list;
    }
    
    public void commandAction(Command c, Displayable s) {
        if (c == playCmd || c == List.SELECT_COMMAND) {
            int pos = list.getSelectedIndex();
            alerts[pos].playSound(display);
        }
        else {
            super.commandAction(c, s);
        }
    }      
}