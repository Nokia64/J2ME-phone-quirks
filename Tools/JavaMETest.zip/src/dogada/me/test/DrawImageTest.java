/*
 * JavaME Test Suite
 * Copyright (C) 2002 Dmytro Dogadaylo
 * 
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 * 
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 *
 * DrawImageTest.java
 *
 */

package dogada.me.test;

import javax.microedition.lcdui.*;
import java.util.Vector;
import java.io.IOException;

/**
 * Loads up to <code>maxImages</code> images from the
 * <code>imgDir</code> and paints it. User can change painting image 
 * by LEFT and RIGHT game action buttons on the phone.
 *
 * @author  Dmytro Dogadaylo, self@dogada.com
 * @version 1.0
 */
public class DrawImageTest extends FPSTest {
    //dir with test images 
    private static final String imgDir = "/img/";
    
    private static final int maxImages = 20;

    private int imageIndex = -1;
    
    private Image[] images;
    
    public void init(Display display, Displayable next) {
        super.init(display, next);
        Vector buf = new Vector();
        int i = 0;
        try {
            while (i < maxImages) {
                Image image = Image.createImage(imgDir + i++ + ".png");
                buf.addElement(image);
            }
        } catch (IOException ioe) {
        }
        images = new Image[buf.size()];
        buf.copyInto(images);
        if (images.length > 0)
            imageIndex = images.length/2;
    }
    
    /**
     * paint
     */
    protected void paint(Graphics g) {
        int x = g.getClipX();
        int y = g.getClipY();
        int w = g.getClipWidth();
        int h = g.getClipHeight();
        int x2 = x + w;
        int y2 = y + h;
        
        String mes = null;
        
        long paintTime = System.currentTimeMillis();
        int drawCount = 0;        
        if (imageIndex > -1) {
            Image image = images[imageIndex];
            int iw = image.getWidth();
            int ih = image.getHeight();
            int anchor = Graphics.TOP | Graphics.LEFT;
            for (int xi = x; xi < x2; xi += iw) {
                for (int yi = y; yi < y2; yi += ih) {
                    g.drawImage(image, xi, yi, anchor);
                    drawCount++;
                }
            }
            paintTime = System.currentTimeMillis() - paintTime;
            
            mes = iw + "x" + ih + "x" + drawCount +
            "=" + paintTime + "ms";
        }
        else {
            g.setColor(0xFF0000);
            g.fillRect(x, y, w, h);
            mes = "Can't load images!";
            pause();
        }
        
        drawInfo(mes, g, x, y, x2, y2);
        
        super.paint(g);
    }
    
    public String getHelp() {
        String helpStr = 
        "UP/DOWN - changes drawing image\n" + 
        "FIRE - show/hide fps indicator"; 
        return helpStr;
    }    
    
    protected void handleKey(int keyCode) {
        if (images.length > 0) {
            int action = getGameAction(keyCode);
            switch (action) {
                case UP:
                    imageIndex++;
                    if (imageIndex >= images.length)
                        imageIndex = 0;
                    reset();
                    break;                
                case DOWN:
                    imageIndex--;
                    if (imageIndex < 0)
                        imageIndex = images.length - 1;
                    reset();
                    break;
                default:
                    super.handleKey(keyCode);
                
            }
        }
    }
}