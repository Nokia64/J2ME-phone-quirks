JavaME Test Suite
Copyright (C) 2002 Dmytro Dogadaylo


There are many devices with J2ME support. Some of them are available only 
in North America, some - in Japan and South Korea, other - in Europe. If 
you want to know how fast your app will work on most devices you will 
need buy a world map and go to the long trip. Main idea of the J2ME Test 
Suite is to have results of running SAME tests on DIFFERENT devices.



TESTS DESCRIPTION


FillRectTest

Application calls Graphics.fillRectangle(int x, int y, int w, int h) and 
fills the screen by white and black rectangles. By pressing 'UP' or 'DOWN' 
you can change painting rectangle size.

Info string at the bottom of the screen '6x6x272=481ms' means that at the 
last painting cycle were filled 272 rectangles 6x6 pixels size for 481 ms.


DrawImageTest

Applications calls Graphics.drawImage(Image image, int x, int y, int anchor) 
and fills screen by the current image. By pressing 'UP' or 'DOWN' you can 
change current image.

Info string at the bottom of the screen '8x8x156=190ms' means that at the 
last painting cycle were painted 156 images 8x8 pixels size for 190 ms.


CalcTest

Application calls CalcTest.doCalc() method. It very simple but can take up 
to 30 seconds for executing on slow devices. This method calls tree times 
and then average execution time is calculated.

protected void doCalc() {
   int temp = 0;
   for (int i = 0; i < 100000; i++) {
      temp = (temp*i)/(i+1) + i;
   }
}



DeviceProperties

Application prints following:

Runtime.freeMemory();
Runtime.totalMemory();
Display.isColor();
Display.numColors();
Canvas.getWidth();
Canvas.getHeight();
Canvas.isDoubleBuffered();
Canvas.hasRepeatEvents();
Canvas.hasPointerEvents();
Canvas.hasPointerMotionEvents();
System.getProperty("microedition.configuration");
System.getProperty("microedition.profiles");
System.getProperty("microedition.platform");
System.getProperty("microedition.locale");
System.getProperty("microedition.encoding");


ColorTest
Shows available on the device colors.


SoundTest
Plays available on the device sounds.

 
FontTest 
Draws test string 'Phones are strange' with different faces, styles and sizes. 
Also it shows width and height for each face/style/size configuration.

For more details see source code. 


Feel free to send me on the javame@dogada.com test results for your device. I 
add it to the freely available test results list (www.dogada.com/javame/results/) 
and publish it in the javame@freelists.org discussion list. For submission 
format see file empty-form.xml.

IMPORTANT NOTE:
For all fps-tests that you will send both fps indicator and additional info at 
the bottom of the screen must be showed. You can enable/disable additional info 
at the bottom of the screen by pressing 'FIRE'.


Dmytro Dogadaylo,
self@dogada.com.